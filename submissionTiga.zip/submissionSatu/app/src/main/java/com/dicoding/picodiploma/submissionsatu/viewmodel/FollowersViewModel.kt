package com.dicoding.picodiploma.submissionsatu.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.picodiploma.submissionsatu.api.ApiConfig
import com.dicoding.picodiploma.submissionsatu.api.UserDataObject
import com.dicoding.picodiploma.submissionsatu.api.UserFfAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowersViewModel : ViewModel() {

    private val rvFollower = MutableLiveData<ArrayList<UserFfAdapter>>()
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun followerSet(username: String?) {
        _isLoading.value = true
        val followerGets = ApiConfig.getApiService().usersFollowerGet(username)
        followerGets.enqueue(object : Callback<List<UserDataObject>> {
            override fun onResponse(
                call: Call<List<UserDataObject>>,
                response: Response<List<UserDataObject>>
            ) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    val listFoll = ArrayList<UserFfAdapter>()
                    for (zero in responseBody) {
                        val follAdapter = UserFfAdapter(zero.username, zero.photo)
                        listFoll.add(follAdapter)
                    }
                    rvFollower.postValue(listFoll)
                    _isLoading.value = false
                    Log.d(TAG, "${rvFollower}")
                }
                else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<UserDataObject>>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    fun followerGet(): LiveData<ArrayList<UserFfAdapter>> {
        return rvFollower
    }

    companion object {
        private val TAG = FollowersViewModel::class.java.simpleName
    }
}
