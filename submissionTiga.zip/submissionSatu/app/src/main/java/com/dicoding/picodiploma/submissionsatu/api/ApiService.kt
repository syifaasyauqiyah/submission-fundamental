package com.dicoding.picodiploma.submissionsatu.api

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @Headers("Authorization: token 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")
    @GET("search/users")
    fun searchQueryGet(
        @Query("q") login: String
    ): Call<User>

    @GET("users/{login}/following")
    fun usersFollowingGet(
        @Path("login") login: String?
    ): Call<List<UserDataObject>>

    @GET("users/{login}/followers")
    fun usersFollowerGet(
        @Path("login") login: String?
    ): Call<List<UserDataObject>>
}