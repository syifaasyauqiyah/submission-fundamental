package com.dicoding.picodiploma.submissionsatu

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.submissionsatu.adapter.FollAdapter
import com.dicoding.picodiploma.submissionsatu.adapter.ListUserAdapter
import com.dicoding.picodiploma.submissionsatu.api.UserFfAdapter
import com.dicoding.picodiploma.submissionsatu.databinding.FragmentFollowersBinding
import com.dicoding.picodiploma.submissionsatu.viewmodel.FollowersViewModel

class FollowersFragment : Fragment() {

    private lateinit var binding: FragmentFollowersBinding
    private lateinit var followersViewModel: FollowersViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFollowersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val username = arguments?.getString(ARG_USERNAME)
        followersViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            FollowersViewModel::class.java)
        followersViewModel.apply { showLoading(false) }
        followersViewModel.followerSet(username)
        followersViewModel.followerGet().observe(viewLifecycleOwner, {rvFollower ->
            setFollowerAdapter(rvFollower)
        })
    }

    private fun setFollowerAdapter(listFoll : ArrayList<UserFfAdapter>) {
        binding.rvFollowers.setHasFixedSize(true)
        Log.d(TAG, "onSuccess ${listFoll.size}")
        val layoutManager = LinearLayoutManager(activity)
        binding.rvFollowers.layoutManager = layoutManager
        val follAdapter = FollAdapter(listFoll)
        binding.rvFollowers.adapter = follAdapter
    }

    private fun showLoading(state: Boolean){
        if (state){
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    companion object {
        private val ARG_USERNAME = "username"

        fun newInstance(username: String?): FollowersFragment {
            val fragment = FollowersFragment()
            val bundle = Bundle()
            bundle.putString(ARG_USERNAME, username)
            fragment.arguments = bundle
            return fragment
        }
    }
}
