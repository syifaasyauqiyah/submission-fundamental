package com.dicoding.picodiploma.submissionsatu.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.picodiploma.submissionsatu.api.ApiConfig
import com.dicoding.picodiploma.submissionsatu.api.User
import com.dicoding.picodiploma.submissionsatu.database.FavoritedEntity
import retrofit2.Call
import retrofit2.Response

class MainViewModel : ViewModel() {
    companion object{
        private val TAG = MainViewModel::class.java.simpleName
    }

    private val listUser = MutableLiveData<List<FavoritedEntity>>()

    fun setUser(users: String) {
        val asyncClient = ApiConfig.getApiService().searchQueryGet(users)
        asyncClient.enqueue(object : retrofit2.Callback<User> {
            override fun onResponse(
                call: Call<User>,
                response: Response<User>
            ) {
                if(response.isSuccessful) {
                    val listItemUser = ArrayList<FavoritedEntity>()
                    val responseBody = response.body()
                    if (responseBody != null) {
                        val listItem = responseBody.items
                        for (zero in listItem) {
                            val listAdapter = FavoritedEntity(zero.id, zero.username, zero.url, zero.photo, isLiked = false)
                            listItemUser.add(listAdapter)
                        }
                        listUser.postValue(listItemUser)
                    }
                }
                else {
                    Log.e(TAG,"onFailure: ${response.message()}" )
                }
            }
            override fun onFailure(call: Call<User>, t: Throwable) {

            }
        })
    }

    fun getUser(): LiveData<List<FavoritedEntity>>{
        return listUser
    }
}