package com.dicoding.picodiploma.submissionsatu.repo

import android.app.Application
import androidx.lifecycle.LiveData
import com.dicoding.picodiploma.submissionsatu.database.DAO
import com.dicoding.picodiploma.submissionsatu.database.DatabaseUser
import com.dicoding.picodiploma.submissionsatu.database.FavoritedEntity
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class UserLikedRepository (application: Application){
    private val mDAO: DAO
    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()

    init {
        val database = DatabaseUser.databaseGet(application)
        mDAO = database.dao()
    }

    fun userLikedGet(): LiveData<List<FavoritedEntity>> = mDAO.userLikedGet()

    fun insert(user: FavoritedEntity) {
        executorService.execute { mDAO.userLikedInsert(user) }
    }

    fun likedDelete(id: Int) {
        executorService.execute { mDAO.userLikedDelete(id) }
    }
}