package com.dicoding.picodiploma.submissionsatu.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [FavoritedEntity::class], version = 1, exportSchema = false)
abstract class DatabaseUser : RoomDatabase(){
    abstract fun dao(): DAO

    companion object {
        @Volatile
        private var instance: DatabaseUser? = null

        @JvmStatic
        fun databaseGet(context: Context): DatabaseUser {
            if (instance == null) {
                synchronized(DatabaseUser::class.java) {
                    instance = Room.databaseBuilder(context.applicationContext,
                        DatabaseUser::class.java, "User.db").build()
                }
            }
            return instance as DatabaseUser
        }
    }
}