package com.dicoding.picodiploma.submissionsatu

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.submissionsatu.adapter.FollAdapter
import com.dicoding.picodiploma.submissionsatu.adapter.ListUserAdapter
import com.dicoding.picodiploma.submissionsatu.api.UserFfAdapter
import com.dicoding.picodiploma.submissionsatu.databinding.FragmentFollowingBinding
import com.dicoding.picodiploma.submissionsatu.viewmodel.FollowingViewModel

class FollowingFragment : Fragment() {

    private lateinit var binding: FragmentFollowingBinding
    private lateinit var followingViewModel: FollowingViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFollowingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val username = arguments?.getString(ARG_USERNAME)
        followingViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            FollowingViewModel::class.java)
        followingViewModel.apply { showLoading(false) }
        followingViewModel.followingSet(username)
        followingViewModel.followingGet().observe(viewLifecycleOwner, { rvFollowing ->
            followingAdapterset(rvFollowing)
        })
    }

    private fun followingAdapterset(listFoll: ArrayList<UserFfAdapter>) {
        binding.rvFollowing.setHasFixedSize(true)
        val layoutManager = LinearLayoutManager(activity)
        binding.rvFollowing.layoutManager = layoutManager
        val follAdapter = FollAdapter(listFoll)
        binding.rvFollowing.adapter = follAdapter
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    companion object {
        private val ARG_USERNAME = "username"

        fun newInstance(username: String?): FollowingFragment {
            val fragment = FollowingFragment()
            val bundle = Bundle()
            bundle.putString(ARG_USERNAME, username)
            fragment.arguments = bundle
            return fragment
        }
    }
}
