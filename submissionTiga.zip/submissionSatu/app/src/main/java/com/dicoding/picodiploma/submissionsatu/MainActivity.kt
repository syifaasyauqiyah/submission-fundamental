package com.dicoding.picodiploma.submissionsatu

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.CompoundButton
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.submissionsatu.adapter.ListUserAdapter
import com.dicoding.picodiploma.submissionsatu.database.FavoritedEntity
import com.dicoding.picodiploma.submissionsatu.databinding.ActivityMainBinding
import com.dicoding.picodiploma.submissionsatu.databinding.SettingPreferenceBinding
import com.dicoding.picodiploma.submissionsatu.viewmodel.MainViewModel
import com.dicoding.picodiploma.submissionsatu.viewmodel.PreferenceViewModel
import com.dicoding.picodiploma.submissionsatu.viewmodel.ViewModelFactorySetting

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: ListUserAdapter
    private lateinit var mainViewModel: MainViewModel
    private lateinit var binding: ActivityMainBinding
    private lateinit var bind: SettingPreferenceBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        bind = SettingPreferenceBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)
        showLoading(false)

        supportActionBar?.title = "GitHub Users"

        val layoutManager = LinearLayoutManager(this)
        binding.rvUser.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvUser.addItemDecoration(itemDecoration)

        mainViewModel = ViewModelProvider(this@MainActivity).get(MainViewModel::class.java)

        setListUserAdapter()

        mainViewModel.getUser().observe(this, {itemUser ->
            adapter.setData(itemUser)
            showLoading(false)
        })

        val pref = Preference.getInstance(dataStore)
        val prefViewModel = ViewModelProvider(this, ViewModelFactorySetting(pref)).get(
            PreferenceViewModel::class.java)
        prefViewModel.getThemeSetting().observe(this, { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                bind.switchTheme.isChecked = true
            }
            else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                bind.switchTheme.isChecked = false
            }
        })

        bind.switchTheme.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            prefViewModel.saveThemeSetting(isChecked)
        }
    }

    private fun setListUserAdapter(){
        binding.rvUser.layoutManager = LinearLayoutManager(this)
        adapter = ListUserAdapter()
        adapter.notifyDataSetChanged()
        binding.rvUser.adapter = adapter
        adapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback{
            override fun onItemClicked(data: FavoritedEntity) {
                detailforUser(data)
            }
        })
    }

    private fun detailforUser(data : FavoritedEntity) {
        val detailforUser = Intent(this@MainActivity, SecondActivity::class.java)
        detailforUser.putExtra(SecondActivity.EXTRA_USER, data)
        startActivity(detailforUser)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)

        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.search)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                getDataUserFromApi(query)
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })
        return super.onCreateOptionsMenu(menu)
    }

    fun getDataUserFromApi(username: String){
        if(username.isEmpty()) return
        showLoading(true)
        mainViewModel.setUser(username)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        setMode(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setMode(selectedMode: Int){
        when (selectedMode){
            R.id.setting -> {
                moveToSetting()
            }
            R.id.favorite -> {
                moveToFavorite()
            }
        }
    }

    private fun moveToFavorite(){
        startActivity(Intent(this@MainActivity, FavoritedActivity::class.java))
    }

    private fun moveToSetting() {
        startActivity(Intent(this@MainActivity, PreferenceSetting::class.java))
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    companion object { private const val TAG = "MainActivity" }
}