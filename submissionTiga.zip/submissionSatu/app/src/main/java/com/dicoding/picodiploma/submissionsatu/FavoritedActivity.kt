package com.dicoding.picodiploma.submissionsatu

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.submissionsatu.adapter.ListUserAdapter
import com.dicoding.picodiploma.submissionsatu.database.FavoritedEntity
import com.dicoding.picodiploma.submissionsatu.databinding.ActivityFavoritedBinding
import com.dicoding.picodiploma.submissionsatu.viewmodel.UserLikedViewModel
import com.dicoding.picodiploma.submissionsatu.viewmodel.ViewModelFactory

class FavoritedActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFavoritedBinding
    private lateinit var itemRowUserAdapter: ListUserAdapter
    private lateinit var userLikedGet: UserLikedViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorited)
        binding = ActivityFavoritedBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Favorite User"

        showLoading(true)

        val layoutManager = LinearLayoutManager(this)
        binding.rvList.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvList.addItemDecoration(itemDecoration)
        showUserLikedAdapter()
        userLikedGet = obtainUserLikedViewModel(this@FavoritedActivity)
        userLikedGet.allLikedUserGet().observe(this, {likedList ->
            if (likedList != null) {
                itemRowUserAdapter.setData(likedList)
                showLoading(false)
            }
        })

    }

    private fun obtainUserLikedViewModel(activity: AppCompatActivity):UserLikedViewModel {
        val factory = ViewModelFactory.newInstacne(activity.application)
        return ViewModelProvider(activity, factory).get(UserLikedViewModel::class.java)
    }

    private fun showUserLikedAdapter() {
        binding.rvList.layoutManager = LinearLayoutManager(this)
        itemRowUserAdapter = ListUserAdapter()
        itemRowUserAdapter.notifyDataSetChanged()
        binding.rvList.adapter = itemRowUserAdapter
        itemRowUserAdapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback {
            override fun onItemClicked(data: FavoritedEntity) {
                detailforlUser(data)
            }
        })
    }

    private fun detailforlUser(data: FavoritedEntity){
        val detailUser = Intent(this@FavoritedActivity, SecondActivity::class.java)
        detailUser.putExtra(SecondActivity.EXTRA_USER, data)
        startActivity(detailUser)
    }

    private fun showLoading(state: Boolean) { binding.progressBar.visibility = if (state) View.VISIBLE else View.GONE }
}