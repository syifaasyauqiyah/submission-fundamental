package com.dicoding.picodiploma.submissionsatu.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface DAO {
    @Query("select * from user_liked where isLiked = 1")
    fun userLikedGet(): LiveData<List<FavoritedEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun userLikedInsert(entitasLikedUser: FavoritedEntity)

    @Query("delete from user_liked where id=:id")
    fun userLikedDelete(id:Int)
}