package com.dicoding.picodiploma.submissionsatu

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.submissionsatu.adapter.SectionPagerAdapter
import com.dicoding.picodiploma.submissionsatu.api.ItemsItem
import com.dicoding.picodiploma.submissionsatu.database.FavoritedEntity
import com.dicoding.picodiploma.submissionsatu.databinding.ActivitySecondBinding
import com.dicoding.picodiploma.submissionsatu.viewmodel.DetailViewModel
import com.dicoding.picodiploma.submissionsatu.viewmodel.UserLikedViewModel
import com.dicoding.picodiploma.submissionsatu.viewmodel.ViewModelFactory
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class SecondActivity: AppCompatActivity() {

    private lateinit var binding: ActivitySecondBinding
    private lateinit var detailviewModel: DetailViewModel
    private lateinit var userLikedGet: UserLikedViewModel
    private var followerUrl: String = ""
    private var repoUrl: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecondBinding.inflate(layoutInflater)
        setContentView(binding.root)

        detailviewModel = ViewModelProvider(this@SecondActivity).get(DetailViewModel::class.java)
        detailviewModel.isloading.observe(this,{ showLoading(it) })

        val user = intent.getParcelableExtra<ItemsItem>(EXTRA_USER) as FavoritedEntity

        val sectionsPagerAdapter = SectionPagerAdapter(this)
        sectionsPagerAdapter.username = user.username
        val viewPager: ViewPager2 = binding.viewPager
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = binding.tabs
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(
                TAB_TITLES[position]
            )
        }.attach()
        supportActionBar?.elevation = 0f
        supportActionBar?.title = user.username

        detailviewModel.setDetailUser(user.url)
        detailviewModel.getDetailUser().observe(this, {
            binding.apply {
                Glide.with(this@SecondActivity)
                    .load(it.photo)
                    .into(binding.imgItemPhoto)
                company.text = it.company
                name.text = it.name
                location.text = it.location
            }
            followerUrl = it.followers
            totFollowerUrl(followerUrl)
            repoUrl = it.repository
            totRepoUrl(repoUrl)
        })

        detailviewModel.followingCountSet(user.username!!)
        detailviewModel.followingTotGet().observe(this, {
            binding.following.text = "$it Following"
        })

        userLikedGet = obtainUserLikedViewModel(this@SecondActivity)

        isLikedSet(user.isLiked)
        binding.favorite.setOnClickListener {
            if (user.isLiked == false) {
                user.isLiked = true
                userLikedGet.userInsert(user)
                isLikedSet(user.isLiked)
                Toast.makeText(this@SecondActivity, "Ditambahkan ke Favorite", Toast.LENGTH_SHORT).show()
            }
            else if (user.isLiked == true) {
                user.isLiked = false
                userLikedGet.likedDelete(user.id)
                isLikedSet(user.isLiked)
                Toast.makeText(this@SecondActivity, "Dihapus dari Favorite", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun isLikedSet(state: Boolean){
        if (state) {
            binding.favorite.setImageResource(R.drawable.ic_baseline_favorite_24)
        } else {
            binding.favorite.setImageResource(R.drawable.ic_baseline_favorite_border_24)
        }
    }

    private fun obtainUserLikedViewModel(activity: AppCompatActivity) : UserLikedViewModel {
        val factory = ViewModelFactory.newInstacne(activity.application)
        return ViewModelProvider(activity, factory).get(UserLikedViewModel::class.java)
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    fun totFollowerUrl(followerUrl : String) {
        detailviewModel.followerCountSet(followerUrl)
        detailviewModel.followerTotGet().observe(this, {
            binding.followers2.text = "$it Followers"
        })
    }

    fun totRepoUrl(repoUrl : String) {
        detailviewModel.repoCountSet(repoUrl)
        detailviewModel.repoTotGet().observe(this, {
            binding.repository2.text = "$it Repositories"
        })
    }

    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text1,
            R.string.tab_text2
        )
        const val EXTRA_USER = "extra_user"
    }
}